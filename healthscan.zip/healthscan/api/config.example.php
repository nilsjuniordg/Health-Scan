<?php
/*
 * Pluxee Health Scan · configuração do backend de IA
 * 1. Copie este arquivo como config.php (na mesma pasta /api)
 * 2. Escolha o provedor e cole a sua chave
 * O config.php fica bloqueado para acesso pelo navegador (.htaccess).
 */
return [
  // 'gemini' (Google AI Studio) ou 'anthropic' (Claude)
  'provider' => 'gemini',

  // Google AI Studio: https://aistudio.google.com/apikey
  'gemini_key'   => 'COLE_SUA_CHAVE_AQUI',
  'gemini_model' => 'gemini-2.5-flash',

  // Anthropic: https://console.anthropic.com
  'anthropic_key'   => '',
  'anthropic_model' => 'claude-sonnet-5-5',

  // Domínios que podem chamar a API (vazio = qualquer origem)
  'allowed_hosts' => ['ofertasconsumer.com.br', 'www.ofertasconsumer.com.br'],
];
