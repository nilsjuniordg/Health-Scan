<?php
/*
 * Pluxee Health Scan · configuração do backend de IA
 * ÚNICO PASSO: troque COLE_SUA_CHAVE_AQUI pela sua chave do Google AI Studio
 * (https://aistudio.google.com/apikey) e salve.
 * Este arquivo é bloqueado para acesso pelo navegador (.htaccess).
 */
return [
  'provider' => 'gemini',

  'gemini_key'   => 'COLE_SUA_CHAVE_AQUI',
  'gemini_model' => 'gemini-2.5-flash',

  // Alternativa: Claude (troque provider para 'anthropic' e cole a chave abaixo)
  'anthropic_key'   => '',
  'anthropic_model' => 'claude-sonnet-5-5',

  // Domínios autorizados a usar esta API
  'allowed_hosts' => ['ofertasconsumer.com.br', 'www.ofertasconsumer.com.br'],
];
