<?php
/*
 * Pluxee Health Scan · análise de imagem por IA
 * POST JSON { "mode": "prato" | "rotulo" | "cardapio", "imageBase64": "data:image/jpeg;base64,..." }
 * Responde JSON no formato do modo pedido.
 */
@set_time_limit(90);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function fail($code, $msg) { http_response_code($code); echo json_encode(['error' => $msg], JSON_UNESCAPED_UNICODE); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['diag'])) {
  $cfgD = file_exists(__DIR__ . '/config.php') ? require __DIR__ . '/config.php' : [];
  $out = ['php' => PHP_VERSION, 'curl' => function_exists('curl_init')];
  $get = function ($url, $headers) { $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_HTTPHEADER => $headers]); $r = curl_exec($ch); $c = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); return [$c, json_decode((string)$r, true)]; };
  if (!empty($cfgD['groq_key'])) { [$c, $j] = $get('https://api.groq.com/openai/v1/models', ['Authorization: Bearer ' . $cfgD['groq_key']]); $out['groq'] = ['status' => $c, 'models' => array_map(fn($m) => $m['id'], $j['data'] ?? [])]; }
  if (!empty($cfgD['gemini_key'])) { $t0 = microtime(true); [$c, $j] = $get('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', ['x-goog-api-key: ' . $cfgD['gemini_key']]);
    $out['gemini'] = ['status' => $c, 'ms' => (int)((microtime(true) - $t0) * 1000), 'models' => array_values(array_filter(array_map(fn($m) => str_replace('models/', '', $m['name']), $j['models'] ?? []), fn($n) => str_contains($n, 'flash')))]; }
  echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail(405, 'Use POST');

$cfgFile = __DIR__ . '/config.php';
if (!file_exists($cfgFile)) fail(503, 'Backend de IA não configurado (crie api/config.php)');
$cfg = require $cfgFile;

// origem permitida: o próprio domínio onde a API está hospedada sempre pode,
// além dos domínios (e subdomínios) listados em allowed_hosts
$origin = $_SERVER['HTTP_ORIGIN'] ?? ($_SERVER['HTTP_REFERER'] ?? '');
$reqHost = strtolower((string)parse_url($origin, PHP_URL_HOST));
if ($reqHost) {
  $self = strtolower(preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? ''));
  $ok = ($reqHost === $self) || ($reqHost === 'www.' . $self) || ('www.' . $reqHost === $self);
  foreach (($cfg['allowed_hosts'] ?? []) as $h) {
    $h = strtolower(trim($h));
    if ($h && ($reqHost === $h || str_ends_with($reqHost, '.' . $h))) { $ok = true; break; }
  }
  if (!$ok) fail(403, 'Origem não permitida (' . $reqHost . ')');
}

$raw = file_get_contents('php://input');
if (strlen($raw) > 4 * 1024 * 1024) fail(413, 'Imagem grande demais');
$body = json_decode($raw, true);
$mode = $body['mode'] ?? 'prato';
$img  = $body['imageBase64'] ?? '';
if (!in_array($mode, ['prato', 'rotulo', 'cardapio'], true)) fail(400, 'Modo inválido');
if (!preg_match('#^data:(image/(jpeg|png|webp));base64,(.+)$#', $img, $m)) fail(400, 'Imagem inválida');
$mime = $m[1]; $b64 = $m[3];

/* ---------- prompts ---------- */
$common = "Responda SOMENTE com um JSON válido, sem texto antes ou depois, sem markdown. Use português do Brasil. Números sem unidade.";
$prompts = [
  'prato' => "Você é um nutricionista especialista em comida brasileira e na Tabela TACO.
Analise a foto e liste TODOS os alimentos visíveis no prato, separadamente (ex.: arroz, feijão, bife, batata frita, tomate, alface, farofa, molho). Não junte itens diferentes num só. Inclua acompanhamentos pequenos e guarnições.
Para cada item estime a porção em gramas pelo tamanho no prato e calcule calorias e macros com base na TACO.
Se não for comida, devolva items vazio e explique em 'erro'.
Formato:
{\"items\":[{\"label\":\"Batata frita\",\"confidence\":0.9,\"portionGrams\":90,\"kcal\":250,\"macros\":{\"carbs\":32,\"protein\":3,\"fat\":12}}],\"erro\":null}
confidence de 0 a 1 indica certeza da identificação. $common",

  'rotulo' => "Você lê rótulos de alimentos e bebidas vendidos no Brasil (padrão ANVISA, RDC 429/2020).
Leia EXATAMENTE o que está escrito na tabela nutricional e na embalagem da foto. Não invente valores: se um campo não estiver visível, use null.
Formato:
{\"produto\":\"nome do produto se visível\",\"porcao\":\"texto da porção, ex. 200 ml\",\"nutrientes\":{\"energia_kcal\":0,\"carboidratos_g\":0,\"acucares_totais_g\":0,\"acucares_adicionados_g\":0,\"proteinas_g\":0,\"gorduras_totais_g\":0,\"gorduras_saturadas_g\":0,\"fibras_g\":0,\"sodio_mg\":0},
\"selos_frontais\":[\"ALTO EM açúcar adicionado\"],\"ingredientes_destaque\":[\"até 3 ingredientes relevantes\"],
\"resumo\":\"1 ou 2 frases simples, sem julgamento, explicando o que isso significa no dia a dia\",\"legivel\":true}
selos_frontais: liste só os selos de lupa realmente impressos; se não houver, lista vazia. legivel=false se a foto não permitir ler a tabela. $common",

  'cardapio' => "Você lê cardápios e lousas de restaurantes brasileiros.
Liste os pratos que conseguir ler na foto, com o preço se aparecer, e estime as calorias de uma porção típica com base na TACO. Conte quantas cores de alimentos o prato costuma ter (variedade de vegetais).
Formato:
{\"restaurante\":\"nome se visível ou null\",\"pratos\":[{\"nome\":\"Frango grelhado com legumes\",\"preco\":29.9,\"kcal\":560,\"cores\":4}],\"legivel\":true}
Use null para preço não visível. $common"
];
$prompt = $prompts[$mode];

/* ---------- chamada aos provedores ---------- */
function http_json($url, $headers, $payload, $timeout = 30) {
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout,
    CURLOPT_HTTPHEADER => array_merge(['Content-Type: application/json'], $headers),
    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
  ]);
  $res = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
  if ($res === false) return [0, null, 'conexão: ' . $err];
  return [$code, json_decode($res, true), $res];
}
function has_key($k) { return !empty($k) && !str_starts_with($k, 'COLE_'); }

/* Cada função devolve ['ok'=>bool, 'text'=>string, 'err'=>string] */
function call_gemini($cfg, $mime, $b64, $prompt, $deadline) {
  if (!has_key($cfg['gemini_key'] ?? '')) return ['ok' => false, 'err' => 'Chave Gemini ausente'];
  $queue = array_values(array_unique([$cfg['gemini_model'] ?? 'gemini-3.8-flash', 'gemini-flash-latest', 'gemini-flash-lite-latest']));
  $tried = []; $err = '';
  while ($queue && microtime(true) < $deadline) {
    $model = array_shift($queue); if (in_array($model, $tried, true)) continue; $tried[] = $model;
    [$code, $j, $raw] = http_json("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
      ['x-goog-api-key: ' . $cfg['gemini_key']],
      ['contents' => [['parts' => [['inline_data' => ['mime_type' => $mime, 'data' => $b64]], ['text' => $prompt]]]],
       'generationConfig' => ['responseMimeType' => 'application/json', 'maxOutputTokens' => 8192, 'temperature' => 0.2]],
      max(5, min(18, (int)($deadline - microtime(true)))));
    if ($code === 200) {
      $t = ''; foreach (($j['candidates'][0]['content']['parts'] ?? []) as $p) if (empty($p['thought'])) $t .= $p['text'] ?? '';
      if (trim($t) !== '') return ['ok' => true, 'text' => $t, 'via' => "gemini:$model"];
      $err = 'Gemini respondeu vazio'; continue;
    }
    $err = 'Gemini ' . $code . ': ' . substr($j['error']['message'] ?? $raw, 0, 160);
    if ($code === 404 && preg_match('#use\s+models/([\w.\-]+)#i', $j['error']['message'] ?? '', $mm)) array_unshift($queue, $mm[1]);
    if (in_array($code, [0, 400, 401, 403], true)) break; // sem resposta, chave ou pedido inválido: passa pro próximo provedor
  }
  return ['ok' => false, 'err' => $err ?: 'Gemini indisponível'];
}

function call_groq($cfg, $mime, $b64, $prompt, $deadline) {
  if (!has_key($cfg['groq_key'] ?? '')) return ['ok' => false, 'err' => 'Chave Groq ausente'];
  $auth = ['Authorization: Bearer ' . $cfg['groq_key']];
  // descobre os modelos com visão disponíveis na conta (a lista do Groq muda com frequência)
  $ch = curl_init('https://api.groq.com/openai/v1/models');
  curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_HTTPHEADER => $auth]);
  $list = json_decode((string)curl_exec($ch), true); curl_close($ch);
  $ids = array_map(fn($m) => $m['id'], $list['data'] ?? []);
  $vision = array_values(array_filter($ids, fn($id) => preg_match('#qwen3\.\d+-\d+b|qwen.*vl|llama-4|scout|maverick|vision|gemma-?3|kimi.*vl|pixtral#i', $id)));
  $models = array_values(array_unique(array_filter(array_merge([$cfg['groq_model'] ?? null], $vision))));
  if ($ids) $models = array_values(array_filter($models, fn($m) => in_array($m, $ids, true)));
  if (!$models) return ['ok' => false, 'err' => 'Groq: nenhum modelo com visão disponível (' . implode(', ', array_slice($ids, 0, 8)) . ')'];
  $errs = [];
  foreach (array_slice($models, 0, 3) as $model) {
    if (microtime(true) >= $deadline) break;
    $payload = ['model' => $model, 'temperature' => 0.2, 'max_completion_tokens' => 4096,
      'response_format' => ['type' => 'json_object'],
      'messages' => [['role' => 'user', 'content' => [
        ['type' => 'text', 'text' => $prompt],
        ['type' => 'image_url', 'image_url' => ['url' => "data:$mime;base64,$b64"]]]]]];
    if (str_starts_with($model, 'qwen/')) $payload['reasoning_effort'] = 'none';
    for ($k = 0; $k < 2; $k++) {
      [$code, $j, $raw] = http_json('https://api.groq.com/openai/v1/chat/completions', $auth, $payload, max(5, min(25, (int)($deadline - microtime(true)))));
      if ($code === 200) {
        $t = $j['choices'][0]['message']['content'] ?? '';
        $t = preg_replace('#<think>.*?</think>#s', '', $t);
        if (trim($t) !== '') return ['ok' => true, 'text' => $t, 'via' => "groq:$model"];
        $errs[] = "$model: resposta vazia"; break;
      }
      $msg = substr($j['error']['message'] ?? (string)$raw, 0, 140);
      // tira parâmetros que o modelo não aceita e tenta de novo
      if ($code === 400 && isset($payload['reasoning_effort'])) { unset($payload['reasoning_effort']); continue; }
      if ($code === 400 && isset($payload['response_format']) && stripos($msg, 'json') !== false) { unset($payload['response_format']); continue; }
      $errs[] = "$model $code: $msg"; break;
    }
    if (!empty($code) && $code === 401) break;
  }
  return ['ok' => false, 'err' => 'Groq · ' . implode(' / ', $errs)];
}

function call_anthropic($cfg, $mime, $b64, $prompt, $deadline) {
  if (!has_key($cfg['anthropic_key'] ?? '')) return ['ok' => false, 'err' => 'Chave Anthropic ausente'];
  [$code, $j, $raw] = http_json('https://api.anthropic.com/v1/messages',
    ['x-api-key: ' . $cfg['anthropic_key'], 'anthropic-version: 2023-06-01'],
    ['model' => $cfg['anthropic_model'] ?? 'claude-sonnet-5-5', 'max_tokens' => 4096,
     'messages' => [['role' => 'user', 'content' => [
       ['type' => 'image', 'source' => ['type' => 'base64', 'media_type' => $mime, 'data' => $b64]],
       ['type' => 'text', 'text' => $prompt]]]]], max(5, min(30, (int)($deadline - microtime(true)))));
  if ($code !== 200) return ['ok' => false, 'err' => 'Anthropic ' . $code . ': ' . substr($j['error']['message'] ?? $raw, 0, 160)];
  $t = ''; foreach (($j['content'] ?? []) as $c) if (($c['type'] ?? '') === 'text') $t .= $c['text'];
  return ['ok' => trim($t) !== '', 'text' => $t, 'err' => 'Anthropic respondeu vazio', 'via' => 'anthropic'];
}

// ordem: provedor principal, depois os reservas que tiverem chave
$order = array_values(array_unique(array_merge([$cfg['provider'] ?? 'gemini'], $cfg['fallbacks'] ?? ['groq', 'anthropic', 'gemini'])));
$deadline = microtime(true) + 55;
$errors = []; $text = ''; $via = '';
foreach ($order as $prov) {
  if (microtime(true) >= $deadline) break;
  $fn = 'call_' . $prov; if (!function_exists($fn)) continue;
  $r = $fn($cfg, $mime, $b64, $prompt, $prov === $order[0] ? min($deadline, microtime(true) + 22) : $deadline);
  if (!empty($r['ok'])) { $text = $r['text']; $via = $r['via'] ?? $prov; break; }
  if (!str_contains($r['err'], 'ausente')) $errors[] = $r['err'];
}
if ($text === '') fail(503, $errors ? 'IA indisponível agora. ' . implode(' | ', $errors) : 'Nenhuma chave de IA configurada');
header('X-AI-Provider: ' . $via);

/* ---------- limpeza e validação do JSON ---------- */
$text = trim(preg_replace('/^```(json)?|```$/m', '', $text));
$start = strpos($text, '{'); $end = strrpos($text, '}');
if ($start === false || $end === false) fail(502, 'A IA não devolveu dados legíveis');
$data = json_decode(substr($text, $start, $end - $start + 1), true);
if (!is_array($data)) fail(502, 'A IA devolveu um formato inesperado');

if ($mode === 'prato') {
  $items = [];
  foreach (($data['items'] ?? []) as $it) {
    if (empty($it['label'])) continue;
    $items[] = [
      'label' => (string)$it['label'],
      'confidence' => max(0, min(1, (float)($it['confidence'] ?? 0.7))),
      'portionGrams' => (int)round($it['portionGrams'] ?? 0),
      'kcal' => (int)round($it['kcal'] ?? 0),
      'macros' => ['carbs' => (float)($it['macros']['carbs'] ?? 0), 'protein' => (float)($it['macros']['protein'] ?? 0), 'fat' => (float)($it['macros']['fat'] ?? 0)],
    ];
  }
  if (!$items) fail(422, $data['erro'] ?? 'Não encontrei alimentos nessa foto');
  echo json_encode(['items' => $items], JSON_UNESCAPED_UNICODE);
} else {
  echo json_encode($data, JSON_UNESCAPED_UNICODE);
}
